/*
 * Copyright 2024 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

@file:Suppress("JUnitMalformedDeclaration", "unused")

package androidx.benchmark.samples

import android.content.Intent
import androidx.annotation.Sampled
import androidx.benchmark.macro.StartupMode
import androidx.benchmark.macro.StartupTimingMetric
import androidx.benchmark.macro.junit4.MacrobenchmarkRule
import androidx.test.ext.junit.runners.AndroidJUnit4
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

@Sampled
fun macrobenchmarkRuleSample() {
    @RunWith(AndroidJUnit4::class)
    class StartupMacrobenchmark {
        @get:Rule val benchmarkRule = MacrobenchmarkRule()

        @Test
        fun startup() =
            benchmarkRule.measureRepeated(
                packageName = "com.example.my.application.id",
                metrics = listOf(StartupTimingMetric()),
                iterations = 5,
                startupMode = StartupMode.COLD,
                setupBlock = { pressHome() },
            ) { // this = MacrobenchmarkScope
                val intent = Intent()
                intent.setPackage(packageName)
                intent.setAction("com.example.my.application.id.myaction")
                startActivityAndWait(intent)
            }
    }
}
