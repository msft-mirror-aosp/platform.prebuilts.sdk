/*
 * Copyright 2019 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package androidx.camera.core.impl;

import org.jspecify.annotations.NonNull;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Different implementations of {@link CameraCaptureCallback}.
 */
public final class CameraCaptureCallbacks {
    private CameraCaptureCallbacks() {
    }

    /** Returns a camera capture callback which does nothing. */
    public static @NonNull CameraCaptureCallback createNoOpCallback() {
        return new NoOpCameraCaptureCallback();
    }

    /** Returns a camera capture callback which calls a list of other callbacks. */
    static @NonNull CameraCaptureCallback createComboCallback(
            @NonNull List<CameraCaptureCallback> callbacks) {
        if (callbacks.isEmpty()) {
            return createNoOpCallback();
        } else if (callbacks.size() == 1) {
            return callbacks.get(0);
        }
        return new ComboCameraCaptureCallback(callbacks);
    }

    /** Returns a camera capture callback which calls a list of other callbacks. */
    public static @NonNull CameraCaptureCallback createComboCallback(
            CameraCaptureCallback @NonNull ... callbacks) {
        return createComboCallback(Arrays.asList(callbacks));
    }

    static final class NoOpCameraCaptureCallback extends CameraCaptureCallback {
        @Override
        public void onCaptureStarted(int captureConfigId) {
        }

        @Override
        public void onCaptureCompleted(int captureConfigId,
                @NonNull CameraCaptureResult cameraCaptureResult) {
        }

        @Override
        public void onCaptureFailed(int captureConfigId, @NonNull CameraCaptureFailure failure) {
        }
    }

    /**
     * A CameraCaptureCallback which contains a list of CameraCaptureCallback and will propagate
     * received callback to the list.
     */
    public static final class ComboCameraCaptureCallback extends CameraCaptureCallback {
        private final List<CameraCaptureCallback> mCallbacks = new ArrayList<>();

        ComboCameraCaptureCallback(@NonNull List<CameraCaptureCallback> callbacks) {
            for (CameraCaptureCallback callback : callbacks) {
                // A no-op callback doesn't do anything, so avoid adding it to the final list.
                if (!(callback instanceof NoOpCameraCaptureCallback)) {
                    mCallbacks.add(callback);
                }
            }
        }

        @Override
        public void onCaptureStarted(int captureConfigId) {
            for (CameraCaptureCallback callback : mCallbacks) {
                callback.onCaptureStarted(captureConfigId);
            }
        }

        @Override
        public void onCaptureCompleted(int captureConfigId,
                @NonNull CameraCaptureResult cameraCaptureResult) {
            for (CameraCaptureCallback callback : mCallbacks) {
                callback.onCaptureCompleted(captureConfigId, cameraCaptureResult);
            }
        }

        @Override
        public void onCaptureFailed(int captureConfigId, @NonNull CameraCaptureFailure failure) {
            for (CameraCaptureCallback callback : mCallbacks) {
                callback.onCaptureFailed(captureConfigId, failure);
            }
        }

        @Override
        public void onCaptureCancelled(int captureConfigId) {
            for (CameraCaptureCallback callback : mCallbacks) {
                callback.onCaptureCancelled(captureConfigId);
            }
        }

        public @NonNull List<CameraCaptureCallback> getCallbacks() {
            return mCallbacks;
        }

        @Override
        public void onCaptureProcessProgressed(int captureConfigId, int progress) {
            for (CameraCaptureCallback callback : mCallbacks) {
                callback.onCaptureProcessProgressed(captureConfigId, progress);
            }
        }
    }
}
