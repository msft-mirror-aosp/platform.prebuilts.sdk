/*
 * This file is auto-generated.  DO NOT MODIFY.
 * Using: /mnt/disks/build-disk/src/googleplex-android/androidx-platform-dev/prebuilts/fullsdk-linux/build-tools/36.0.0/aidl -o/mnt/disks/build-disk/src/googleplex-android/androidx-platform-dev/out/androidx/room/room-runtime/build/generated/source/stable_aidl/androidMain -I/mnt/disks/build-disk/src/googleplex-android/androidx-platform-dev/frameworks/support/room/room-runtime/src/androidMain/stableAidl -I/mnt/disks/build-disk/src/googleplex-android/androidx-platform-dev/out/androidx/room/room-runtime/build/stableAidl -I/mnt/disks/build-disk/src/googleplex-android/androidx-platform-dev/frameworks/support/room/room-runtime/src/androidMain/stableAidlImports -I/mnt/disks/build-disk/src/googleplex-android/androidx-platform-dev/out/androidx/room/room-runtime/build/stableAidlImports -I/mnt/disks/build-disk/src/googleplex-android/androidx-platform-dev/frameworks/support/buildSrc/stableAidlImports -d/mnt/disks/build-disk/src/googleplex-android/androidx-platform-dev/out/tmp/aidl7189694388471735449.d --structured --min_sdk_version 21 /mnt/disks/build-disk/src/googleplex-android/androidx-platform-dev/frameworks/support/room/room-runtime/src/androidMain/stableAidl/androidx/room/IMultiInstanceInvalidationCallback.aidl
 *
 * DO NOT CHECK THIS FILE INTO A CODE TREE (e.g. git, etc..).
 * ALWAYS GENERATE THIS FILE FROM UPDATED AIDL COMPILER
 * AS A BUILD INTERMEDIATE ONLY. THIS IS NOT SOURCE CODE.
 */
package androidx.room;
/** RPC Callbacks for {@link IMultiInstanceInvalidationService}. */
@androidx.annotation.RestrictTo(androidx.annotation.RestrictTo.Scope.LIBRARY)
public interface IMultiInstanceInvalidationCallback extends android.os.IInterface
{
  /** Default implementation for IMultiInstanceInvalidationCallback. */
  public static class Default implements androidx.room.IMultiInstanceInvalidationCallback
  {
    /**
     * Called when invalidation is detected in another instance of the same database.
     * 
     * @param tables List of invalidated table names
     */
    @Override public void onInvalidation(java.lang.String[] tables) throws android.os.RemoteException
    {
    }
    @Override
    public android.os.IBinder asBinder() {
      return null;
    }
  }
  /** Local-side IPC implementation stub class. */
  public static abstract class Stub extends android.os.Binder implements androidx.room.IMultiInstanceInvalidationCallback
  {
    /** Construct the stub and attach it to the interface. */
    @SuppressWarnings("this-escape")
    public Stub()
    {
      this.attachInterface(this, DESCRIPTOR);
    }
    /**
     * Cast an IBinder object into an androidx.room.IMultiInstanceInvalidationCallback interface,
     * generating a proxy if needed.
     */
    public static androidx.room.IMultiInstanceInvalidationCallback asInterface(android.os.IBinder obj)
    {
      if ((obj==null)) {
        return null;
      }
      android.os.IInterface iin = obj.queryLocalInterface(DESCRIPTOR);
      if (((iin!=null)&&(iin instanceof androidx.room.IMultiInstanceInvalidationCallback))) {
        return ((androidx.room.IMultiInstanceInvalidationCallback)iin);
      }
      return new androidx.room.IMultiInstanceInvalidationCallback.Stub.Proxy(obj);
    }
    @Override public android.os.IBinder asBinder()
    {
      return this;
    }
    @Override public boolean onTransact(int code, android.os.Parcel data, android.os.Parcel reply, int flags) throws android.os.RemoteException
    {
      java.lang.String descriptor = DESCRIPTOR;
      if (code >= android.os.IBinder.FIRST_CALL_TRANSACTION && code <= android.os.IBinder.LAST_CALL_TRANSACTION) {
        data.enforceInterface(descriptor);
      }
      if (code == INTERFACE_TRANSACTION) {
        reply.writeString(descriptor);
        return true;
      }
      switch (code)
      {
        case TRANSACTION_onInvalidation:
        {
          java.lang.String[] _arg0;
          _arg0 = data.createStringArray();
          this.onInvalidation(_arg0);
          break;
        }
        default:
        {
          return super.onTransact(code, data, reply, flags);
        }
      }
      return true;
    }
    private static class Proxy implements androidx.room.IMultiInstanceInvalidationCallback
    {
      private android.os.IBinder mRemote;
      Proxy(android.os.IBinder remote)
      {
        mRemote = remote;
      }
      @Override public android.os.IBinder asBinder()
      {
        return mRemote;
      }
      public java.lang.String getInterfaceDescriptor()
      {
        return DESCRIPTOR;
      }
      /**
       * Called when invalidation is detected in another instance of the same database.
       * 
       * @param tables List of invalidated table names
       */
      @Override public void onInvalidation(java.lang.String[] tables) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _data.writeStringArray(tables);
          boolean _status = mRemote.transact(Stub.TRANSACTION_onInvalidation, _data, null, android.os.IBinder.FLAG_ONEWAY);
        }
        finally {
          _data.recycle();
        }
      }
    }
    static final int TRANSACTION_onInvalidation = (android.os.IBinder.FIRST_CALL_TRANSACTION + 0);
  }
  /** @hide */
  public static final java.lang.String DESCRIPTOR = "androidx$room$IMultiInstanceInvalidationCallback".replace('$', '.');
  /**
   * Called when invalidation is detected in another instance of the same database.
   * 
   * @param tables List of invalidated table names
   */
  public void onInvalidation(java.lang.String[] tables) throws android.os.RemoteException;
}
