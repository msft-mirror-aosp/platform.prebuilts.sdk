/*
 * Copyright (C) 2024 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package androidx.compose.remote.core.operations.layout.modifiers;

import static androidx.compose.remote.core.documentation.DocumentedOperation.FLOAT;
import static androidx.compose.remote.core.documentation.DocumentedOperation.INT;

import androidx.annotation.RestrictTo;
import androidx.compose.remote.core.Operation;
import androidx.compose.remote.core.Operations;
import androidx.compose.remote.core.WireBuffer;
import androidx.compose.remote.core.documentation.DocumentationBuilder;
import androidx.compose.remote.core.serialize.MapSerializer;
import androidx.compose.remote.core.serialize.SerializeTags;

import org.jspecify.annotations.NonNull;
import org.jspecify.annotations.Nullable;

import java.util.List;

/** Set the width dimension on a component */
@RestrictTo(RestrictTo.Scope.LIBRARY_GROUP)
public class WidthModifierOperation extends DimensionModifierOperation {
    private static final int OP_CODE = Operations.MODIFIER_WIDTH;
    public static final String CLASS_NAME = "WidthModifierOperation";
    private @Nullable WidthInModifierOperation mWidthIn = null;

    /**
     * The name of the class
     *
     * @return the name
     */
    @NonNull
    public static String name() {
        return CLASS_NAME;
    }

    /**
     * The OP_CODE for this command
     *
     * @return the opcode
     */
    public static int id() {
        return OP_CODE;
    }

    /**
     * Write the operation to the buffer
     *
     * @param buffer a WireBuffer
     * @param type the type of dimension rule (DimensionModifierOperation.Type)
     * @param value the value of the dimension
     */
    public static void apply(@NonNull WireBuffer buffer, int type, float value) {
        buffer.start(OP_CODE);
        buffer.writeInt(type);
        buffer.writeFloat(value);
    }

    /**
     * Read this operation and add it to the list of operations
     *
     * @param buffer the buffer to read
     * @param operations the list of operations that will be added to
     */
    public static void read(@NonNull WireBuffer buffer, @NonNull List<Operation> operations) {
        Type type = Type.fromInt(buffer.readInt());
        float value = buffer.readFloat();
        Operation op = new WidthModifierOperation(type, value);
        operations.add(op);
    }

    public WidthModifierOperation(@NonNull Type type, float value) {
        super(type, value);
    }

    @Override
    public void write(@NonNull WireBuffer buffer) {
        apply(buffer, mType.ordinal(), mValue);
    }

    public WidthModifierOperation(@NonNull Type type) {
        super(type);
    }

    public WidthModifierOperation(float value) {
        super(value);
    }

    @NonNull
    @Override
    public String toString() {
        return "Width(" + mType + ", " + mValue + ")";
    }

    @NonNull
    @Override
    public String serializedName() {
        return "WIDTH";
    }

    /**
     * Populate the documentation with a description of this operation
     *
     * @param doc to append the description to.
     */
    public static void documentation(@NonNull DocumentationBuilder doc) {
        doc.operation("Modifier Operations", OP_CODE, CLASS_NAME)
                .description("define the animation")
                .field(INT, "type", "")
                .field(FLOAT, "value", "");
    }

    /**
     * Set width in constraints
     *
     * @param widthInConstraints width constraints
     */
    public void setWidthIn(@NonNull WidthInModifierOperation widthInConstraints) {
        mWidthIn = widthInConstraints;
    }

    /**
     * Returns width in constraints
     *
     * @return width in constraints
     */
    public @Nullable WidthInModifierOperation getWidthIn() {
        return mWidthIn;
    }

    @Override
    public void serialize(@NonNull MapSerializer serializer) {
        serializer
                .addTags(SerializeTags.MODIFIER)
                .addType("WidthModifierOperation")
                .add("width", mValue, mOutValue)
                .add("dimensionModifierType", mType);
    }
}
