/*
 * Copyright (C) 2024 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package androidx.compose.remote.creation.modifiers;

import androidx.annotation.RestrictTo;
import androidx.compose.remote.core.operations.layout.animation.AnimationSpec;
import androidx.compose.remote.creation.RemoteComposeWriter;

import org.jspecify.annotations.NonNull;

/** Width modifier */
@RestrictTo(RestrictTo.Scope.LIBRARY_GROUP)
public class AnimateSpecModifier implements RecordingModifier.Element {

    int mAnimationId;
    float mMotionDuration;
    int mMotionEasingType;
    float mVisibilityDuration;
    int mVisibilityEasingType;
    AnimationSpec.@NonNull ANIMATION mEnterAnimation;
    AnimationSpec.@NonNull ANIMATION mExitAnimation;

    public AnimateSpecModifier(
            int animationId,
            float motionDuration,
            int motionEasingType,
            float visibilityDuration,
            int visibilityEasingType,
            AnimationSpec.@NonNull ANIMATION enterAnimation,
            AnimationSpec.@NonNull ANIMATION exitAnimation) {
        mAnimationId = animationId;
        mMotionDuration = motionDuration;
        mMotionEasingType = motionEasingType;
        mVisibilityDuration = visibilityDuration;
        mVisibilityEasingType = visibilityEasingType;
        mEnterAnimation = enterAnimation;
        mExitAnimation = exitAnimation;
    }

    @Override
    public void write(@NonNull RemoteComposeWriter writer) {
        writer.addAnimationSpecModifier(
                mAnimationId,
                mMotionDuration,
                mMotionEasingType,
                mVisibilityDuration,
                mVisibilityEasingType,
                mEnterAnimation.ordinal(),
                mExitAnimation.ordinal());
    }
}
